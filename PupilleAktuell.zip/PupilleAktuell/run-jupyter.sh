#!/bin/sh
./run.sh jupyter-lab $@




